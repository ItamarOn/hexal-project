import warnings


warnings.filterwarnings('ignore', category=DeprecationWarning,
                        module='unittest2.compatibility')
